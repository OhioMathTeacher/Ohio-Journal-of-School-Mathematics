# Spring 2026 Submission Inventory
**Created:** March 21, 2026  
**Purpose:** Complete inventory of all submissions in Janeway queue (Review + Copyediting stages)

---

## Overview
- **Total Submissions in Queue:** 10 Spring 2026 active submissions
- **Published (Spring 2026):** 9 articles moved to `Published/` folder
- **Rejected:** 4 papers moved to `Rejected/` folder (Hastings, Pinarbasi, Rahman, Aguilera)
- **Summer Papers Moved:** 7 papers relocated to Ohio-Journal-Summer-2026/ (Guerrero, Cho, Mix, Mahmood, Imaninezhad, Moreno Cabeza, Smith)
- **Summer Papers to Spring:** 1 paper moved from Summer to Spring (Lozano - publishing Spring 2026)
- **Status Files Created:** March 21, 2026
- **Goal:** Review every submission during Spring Break, ensure Janeway and local files are synchronized

### Janeway vs Local Alignment (March 21 Update)
**Spring 2026 Copyediting:** 1 paper (6622 Lozano)  
**Spring 2026 Review:** ~8-9 papers pending decisions  
**Summer 2026 Copyediting:** 3 papers (7188 Imaninezhad, 7236 Moreno Cabeza, 7296 Smith)  
**Prepublication:** 1 paper (6649 Druken - awaiting author corrections)

---

## Note: Summer 2026 Papers
The following 5 submissions are Summer 2026 papers (located in `/Ohio-Journal-Summer-2026/`):
- **6622 Lozano** - "Using AI to Make Definitions Personal"
- **6624 Guerrero**
- **6628 Cho**
- **6776 Mix** - "The First One to the Origin Wins" (R&R deadline extended to June 30, 2026)
- **6915 Mahmood**

---

## Published Spring 2026 Articles (Moved to Published/)
1. **6569 Aguilar** - "Using an AI-Based Chatbot to Support the Learning of Algebraic Factoring" (English)
2. **6569 AguilarES** - "Uso de un chatbot basado en IA para apoyar el aprendizaje de la factorización algebraica" (Spanish)
3. **6616 Selmer** - "Supporting Responsive Mathematics Teaching in Elementary Classrooms Using ChatGPT"
4. **6647 Trivedi** - "Math Isn't Neutral: Redesigning Word Problems with GPT-4 for Relevance"
5. **6674 Moldavan** - "From Prompt to Practice: Using Artificial Intelligence to Support Productive Struggle in Elementary Mathematics Methods Courses"
6. **6902 Alhammouri** - "Helping Students Hit the Target on Probability"
7. **6986 Koca** - "AI as Collaborative Tool for Teachers for Effective Integration of Dynamic Geometry Tools"
8. **7047 Imaninezhad** - "An Elementary Difference-Matrix Evaluation of the Series"
9. **7048 Joswick** - "Recognizing and Celebrating the Life and Times of Raye Montague" + "That's Where I Sit!"

---

## Submission List (10 Active Spring 2026 Papers)

### Papers in Copyediting Stage
**6622 Lozano** - "Using AI to Make Definitions Personal" (moved from Summer to Spring, typesetting March 22)

### Papers in Prepublication
**6649 Druken** - Has main.tex + 1 PDF → **PREPUBLICATION** (awaiting author corrections, due April 4)

### Papers with Active Typesetting (Not Yet in Copyediting)
**6579 Nurnberger-Haag** - Has main.tex (typesetting started, status unclear)  
**7046 Bintz** - Has main.tex + 8 PDFs (active typesetting)  
**7158 Khadka** - 6 PDFs in Deliverables (recently completed R&R, ready for author proofs)

### Papers in Review Stage
**6932 Svoboda** - No typesetting files  
**6938 Gandhi** - No typesetting files  
**6942 Lesser** - R&R decision drafted March 21, to be sent (6 revision priorities, May 15 deadline)  
**6962 Morelo** - Status update sent March 21, review expected March 27  
**7036 Singh** - No typesetting files

---

## Papers Moved to Summer 2026
- **7188 Imaninezhad** - "The Art of Problem Posing" (acceptance sent March 21)
- **7236 Moreno Cabeza** - "Thinking with Machines" (accepted March 17)
- **7296 Smith** - "Fitting it All In" (accepted March 17)

---

## Spring Break Action Items

### ✅ Completed (March 21)
- [x] 7158 Khadka - R&R sent with editorial changes
- [x] Organized published articles (9 moved to Published/)
- [x] Separated Summer 2026 papers (5 duplicates removed)

### 🔴 Phase 1: Email Communications (March 21-22)
- [x] 6962 Morelo - Status update sent
- [ ] 6776 Mix - Deadline extension drafted (Summer 2026 paper, to be sent)
- [ ] 6942 Lesser - R&R drafted (to be sent)
- [ ] 7116 Bintz - Rejection (folder doesn't exist yet)

### 📝 Phase 2: Typesetting Queue (March 22-25) - SPRING 2026 PAPERS
- [ ] Day 1 (March 22): 7188 Imaninezhad - "The Art of Problem Posing: From Bouncing Balls to Infinite Series"
- [ ] Day 2 (March 23): 7236 Moreno Cabeza - "Thinking with Machines..."
- [ ] Day 3 (March 24): 7296 Smith - "Fitting it All In: A Geometric Modeling Task"
- [ ] Day 4 (March 25): [TBD - need to identify 4th Spring paper]

**Note:** 6622 Lozano is a Summer 2026 paper, removed from Spring typesetting queue.

---

## Workflow Notes

### Status File System
- Each submission has a `status.md` file with template structure
- When status is updated, rename to `status_last_revised_[DATE].md`
- Template includes: Timeline, Communications Log, Reviews, Next Actions
- Goal: Keep Janeway and local repository synchronized

### Review Process
- Systematically review each submission folder
- Check for: manuscript files, reviews, decision emails, deliverables
- Update status file with current Janeway stage
- Identify needed actions (emails, decisions, typesetting, etc.)
- Ensure transparent communication with all authors

---

## Questions to Answer for Each Submission
1. What stage is it in Janeway? (Review / Copyediting / Production)
2. When was it submitted?
3. Have reviews been completed?
4. Has a decision been sent?
5. Is author waiting for something from us?
6. Are we waiting for something from author?
7. What's the next action?
8. When was the last communication?
