# OJSM Spring 2026 - Current Status

**Last Updated:** January 17, 2026

---

## TODO: Send Proof Emails (Morning of Jan 17)

- [ ] **7046 Bintz** - Send `Bintz_DRAFT_Jan17v4.pdf` with `Proof_Review_Email.html`
- [ ] **7047 Imaninezhad** - Send `Imaninezhad_DRAFT_Jan17v2.pdf` with `Proof_Review_Email.html`
- [ ] **7048 Joswick** - Send `Joswick_DRAFT_Jan17v3.pdf` with `Proof_Review_Email.html` (note: request hi-res Figure 2 images)

**Response deadline for authors:** January 30, 2026  
**Issue release date:** February 15, 2026

---

## Completed Manuscripts (Typeset Jan 16-17)

### 7046 Bintz ✅
- 3 pages (81–83), single author, text-only bio
- Draft ready, proof email ready

### 7047 Imaninezhad ✅
- 6 pages (75–80), single author
- Draft ready, proof email ready

### 7048 Joswick ✅
- 7 pages (84–90), 3 authors (Joswick, Williams, Felton-Koestler)
- Draft ready, proof email ready
- **Note:** Figure 2 images are low resolution - request hi-res from authors

---

## Active Work: Typeset 6616 Selmer

### Status: READY TO BEGIN TYPESETTING

**Manuscript:** "Supporting Responsive Mathematics Teaching in Elementary Classrooms Using ChatGPT"  
**Author:** Selmer  
**Revision Status:** Accepted with minor editorial additions

### Files to Use
- **Revised submission:** `6616 Selmer/Submissions/The Absolute Latest/selmerresubmission.pdf`
- **Source DOCX:** `6616 Selmer/Submissions/The Absolute Latest/submission.docx`

### Editorial Actions During Typesetting
1. **Add ethics paragraph** (after limitations, before "Teacher educators must think deeply..."):
   > When using AI tools to analyze student work, educators should also consider ethical implications. Uploading student work to commercial AI platforms raises privacy questions, particularly regarding how student data may be stored or used. Teachers should ensure compliance with institutional policies and, where appropriate, obtain parental consent. Additionally, AI systems may exhibit biases in handwriting recognition or language interpretation that could affect analyses of work from diverse student populations. Teacher educators introducing these tools should help prospective teachers develop critical awareness of these considerations.

2. **Track all editorial changes** for proofs email

### After Typesetting
- Send single comprehensive email with:
  - Acceptance congratulations
  - List of all changes made (including ethics paragraph)
  - Options: keep/revise/remove ethics paragraph
  - Request to review proofs

---

## Completed Manuscripts

### 6569 Aguilar ✅
- **English:** 12 pages, proofs sent Jan 13
- **Spanish (AguilarES):** 12 pages, proofs sent Jan 13
- Awaiting author response on Spanish version preference

### 6674 Moldavan ✅
- Typeset complete, drafts in Deliverables

---

## Queue

| Manuscript | Status | Next Action |
|------------|--------|-------------|
| 6616 Selmer | Revision accepted | **Typeset now** |
| 6579 Nurnberger-Haag | Has main.tex | Check status |
| 6622 Lozano | Has main.tex | Check status |
| 6624 Guerrero | Has main.tex | Check status |
| 6628 Cho | Has main.tex | Check status |
| 6647 Trivedi | Has main.tex | Check status |
| 6649 Druken | Has main.tex | Check status |
| 6776 Mix | Has main.tex | Check status |
| 6986 Koca | Has main.tex | Check status |
| 6962 Morelo | Awaiting new reviewer feedback | Decision expected by March 20 |

---

## Notes
- Deleted `scripts/revision_checker.py` - use manual evaluation per `Workflow/04-Revision-Evaluation_PROCESS.md`
- Selmer revision evaluation was initially marked "Not Met" by the deleted script - manual review showed it's actually acceptable
